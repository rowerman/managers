export const serverIp = 'localhost'         //本地接口
//export const serverIp = '这里可以换成你自己的服务器地址'  //服务器接口
