<template>
    <el-card class="sm4-card">
      <div slot="header" class="clearfix">
        <span>SM4 加密/解密</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="密钥（必须提供，16字节）">
          <el-input v-model="sm4Key" placeholder="请输入密钥（16字节）"></el-input>
        </el-form-item>
        <el-form-item label="明文（加密用）">
          <el-input v-model="plaintext" type="textarea" placeholder="请输入明文..."></el-input>
        </el-form-item>
        <el-form-item label="密文（解密用）">
          <el-input v-model="ciphertext" type="textarea" placeholder="请输入密文..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="sendEncryptRequest">加密</el-button>
          <el-button type="success" @click="sendDecryptRequest">解密</el-button>
        </el-form-item>
        <el-form-item label="生成的密文">
          <el-input v-model="generatedCiphertext" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="解密后的明文">
          <el-input v-model="decryptedPlaintext" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  export default {
    name: 'SM4Encryption',
    data() {
      return {
        socket: null,
        sm4Key: '',
        plaintext: '',
        ciphertext: '',
        generatedCiphertext: '',
        decryptedPlaintext: '',
      };
    },
    created() {
      this.connect();
    },
    methods: {
      connect() {
        this.socket = new WebSocket('ws://192.168.80.133:8765');
        this.socket.onopen = () => {
          console.log('WebSocket connected');
        };
        this.socket.onmessage = (event) => {
        const response = JSON.parse(event.data);
        console.log('Received data:', response);  // 打印收到的数据
        if (response.message_type === 'server_reply') {
          if (response.message === 'SM4_encrypt_result') {
            this.generatedCiphertext = response.package.ciphertext;
            this.sm4Key = response.package.key;
          } else if (response.message === 'SM4_decrypt_result') {
            // 判断是否解密成功
            if(response.package.message){
              this.decryptedPlaintext = response.package.message;
            } else {
              console.error('Decryption failed:', response.package);
            }
          }
        }
      };
    },
      sendEncryptRequest() {
      const keyType = this.sm4Key.length === 16 ? 1 : 3;
      const message = {
        source: "crypt",
        type: 'SM4_encrypt',
        content: {
          message: this.plaintext,
          key: this.sm4Key,
          type: keyType,
          filepath: '' // Assuming filepath is not used in this context
        }
      };
      console.log(message);
      this.socket.send(JSON.stringify(message));
    },
      sendDecryptRequest() {
        const message = {
          source: "crypt",
          type: 'SM4_decrypt',
          content: {
            ciphertext: this.ciphertext,
            key: this.sm4Key
          }
        };
        this.socket.send(JSON.stringify(message));
      },
    },
  };
  </script>

  
  <style scoped>
  .sm4-card {
    margin-bottom: 20px;
  }
  </style>
  