<template>
    <el-container class="full-height">
      <el-card class="full-height watermark-embedding-card">
        <div slot="header" class="clearfix">
          <span>嵌入水印到图片</span>
        </div>
        <el-form label-position="top">
          <el-form-item label="选择图片">
            <el-upload
              class="upload-demo"
              :on-change="handleImageChange"
              :before-upload="beforeUpload"
              :auto-upload="false"
              accept="image/*"
              action="#">
              <el-button slot="trigger" size="small" type="primary">选取图片</el-button>
              <div slot="tip" class="el-upload__tip">支持jpg/png等格式</div>
            </el-upload>
          </el-form-item>
          <el-form-item label="选择水印">
            <el-upload
              class="upload-demo"
              :on-change="handleWatermarkChange"
              :before-upload="beforeUpload"
              :auto-upload="false"
              accept="image/*"
              action="#">
              <el-button slot="trigger" size="small" type="primary">选取水印</el-button>
              <div slot="tip" class="el-upload__tip">支持jpg/png等格式</div>
            </el-upload>
          </el-form-item>
          <el-form-item>
            <el-button type="success" @click="embedWatermark">嵌入水印并下载</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </el-container>
  </template>
  
  <script>
  export default {
    name: 'WatermarkEmbedding',
    data() {
      return {
        selectedImage: null,
        selectedWatermark: null,
      };
    },
    methods: {
      handleImageChange(file, fileList) {
        // 保存用户选择的图片
        this.selectedImage = file.raw;
      },
      handleWatermarkChange(file, fileList) {
        // 保存用户选择的水印图片
        this.selectedWatermark = file.raw;
      },
      beforeUpload() {
        // 阻止自动上传
        return false;
      },
      embedWatermark() {
        if (!this.selectedImage || !this.selectedWatermark) {
          this.$message.error("请选择图片和水印！");
          return;
        }
        // 在这里实现将图片和水印发送到后端的逻辑
        // 示例代码省略了实际的上传逻辑，您需要根据后端API进行相应的调整
        console.log("执行嵌入水印操作", this.selectedImage, this.selectedWatermark);
        // 假设嵌入成功后，触发浏览器下载处理后的图片
        // 这里需要后端返回处理后的图片URL
        // 下面的代码是模拟下载行为的示例
        // const downloadUrl = "your-processed-image-url";
        // window.open(downloadUrl, '_blank');
      },
    },
  };
  </script>
  
  <style scoped>
  .full-height {
    height: 100vh;
    display: flex;
    flex-direction: column;
  }
  
  .watermark-embedding-card {
    flex-grow: 1;
    margin-bottom: 0;
  }
  </style>
  