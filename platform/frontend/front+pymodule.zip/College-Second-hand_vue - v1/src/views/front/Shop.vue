<template>
  <div style="margin-top: 100px">
        <el-carousel
      :interval="4000"
      type="card"
      height="400px"
      style="margin: 0 auto; width: 1200px"
    >
      <el-carousel-item v-for="item in item" :key="item.id">
        <a :href="item.paperUrl" target="_blank">
          <img :src="item.idView" style="width: 100%; height: 100%" />
        </a>
      </el-carousel-item>
    </el-carousel>

    <div
      style="
        display: flex;
        align-items: center;
        justify-content: center;
        padding-top: 40px;
      "
    >
      <el-input
        style="width: 600px"
        clearable
        size="medium"
        placeholder="请输入帖子名"
        v-model="gname"
        class="input-with-select"
      >
        <el-button
          slot="append"
          icon="el-icon-search"
          @click="load"
        ></el-button>
      </el-input>
    </div>

    <el-row
      style="
        margin: 0 auto;
        width: 1200px;
        padding-top: 50px;
        padding-bottom: 80px;
      "
      :gutter="12"
    >
      <div style="padding-left: 30px; padding-bottom: 20px">
        <span v-if="total_sum == 0">
          <el-empty :image-size="200"></el-empty>
        </span>
        <span v-else style="color: #949494">共发现 {{ total_sum }} 个帖子</span>
      </div>
      <el-col
        :span="4"
        v-for="goods_list in filteredGoodsList"
        :key="goods_list.gid"
        style="padding: 15px; min-width: 240px; margin-top: 20px"
      >
        <el-card
          v-if="goods_list.gstatus == 1"
          :body-style="{ padding: '0px' }"
          shadow="hover"
          style="
            cursor: pointer;
            border-radius: 15px;
            border: 1px solid #87ceeb; /* 天蓝色的实线边框 */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* 轻微阴影效果提升立体感 */
          "
          @click.native="goods_details(goods_list.gid)"
        >
          <div
            v-if="goods_list.gdescribe !== null"
            style="
              height: 208px;
              width: 208px;
              padding: 14px;
              overflow: hidden;
              text-overflow: ellipsis;
              background-color: #f0f8ff; /* 背景使用更淡的天蓝色 */
            "
          >
            {{ goods_list.gdescribe }}
          </div>

          <div style="padding: 14px">
            <span>{{ goods_list.gname | ellipsis }}</span>
            <div class="bottom clearfix">
              <span class="time">
                <i class="el-icon-s-shop"></i>
                {{ goods_list.sellusername }}
              </span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <div style="text-align: center; padding-bottom: 20px">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageNum"
        background
        :page-sizes="[10, 20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>

    <transition name="fade">
      <loading v-if="isLoading"></loading>
    </transition>
  </div>
</template>

<script>
import Loading from "/src/components/loading.vue";
export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: true,
      goods_list: [],
      total: 0,
      pageNum: 1,
      pageSize: 20,
      gname: "",
      item: [
        {
          id: 0,
          idView: require('@/assets/images/image1.jpg'),
          paperUrl: "https://ieeexplore.ieee.org/document/9717388"
        },
        {
          id: 1,
          idView: require('@/assets/images/image2.jpg'),
          paperUrl: "https://ieeexplore.ieee.org/document/9955602"
        },
        {
          id: 2,
          idView: require('@/assets/images/image3.jpg'),
          paperUrl: "https://ieeexplore.ieee.org/document/9642824"
        },
        
      ],

    };
  },
  created() {
    this.load();
  },
  filters: {
    // 当标题字数超出时，超出部分显示’...‘。此处限制超出10位即触发隐藏效果
    ellipsis(value) {
      if (!value) return "";
      if (value.length > 10) {
        return value.slice(0, 10) + "...";
      }
      return value;
    },
  },
  computed: {
    filteredGoodsList() {
      return this.goods_list.filter((item) => item.gstatus == 1);
    },
    total_sum() {
      return this.filteredGoodsList.length; // 根据filteredGoodsList的长度计算total_sum
    },
  },
  methods: {
    load() {
      this.request
        .get("/goods/getGoodsPage", {
          params: {
            pageNum: this.pageNum,
            pageSize: this.pageSize,
            Gname: this.gname,
          },
        })
        .then((res) => {
          this.goods_list = res.data;
          this.total = res.total;

          this.isLoading = false;
        });
    },
    goods_details(id) {
      this.$router.push({
        path: "/goods_details",
        query: {
          gid: id,
        },
      });

      /* const routeData = this.$router.resolve({
					path: '/goods_details',
					query: {
						gid: id
					}
				})
				window.open(routeData.href, '_blank') */
    },
    handleSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.load();
    },
    handleCurrentChange(pageNum) {
      this.pageNum = pageNum;
      this.load();
    },
  },
};
</script>

<style>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

.time {
  font-size: 13px;
  color: #999;
}

.bottom {
  margin-top: 13px;
  line-height: 12px;
}

.button {
  padding: 0;
  float: right;
}

.image {
  width: 100%;
  display: block;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}

.clearfix:after {
  clear: both;
}
.el-col-4 {
  width: 16.66667%;
  height: 300px;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
