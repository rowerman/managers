<template>
    <el-card class="ecc-card">
      <div slot="header" class="clearfix">
        <span>ECC 签名/验证</span>
      </div>
      <el-form label-position="top">
        <el-form-item>
          <el-button type="primary" @click="generateKeys">生成密钥对</el-button>
        </el-form-item>
        <el-form-item label="公钥">
          <el-input v-model="publicKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="私钥">
          <el-input v-model="privateKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="消息">
          <el-input v-model="message" type="textarea" placeholder="请输入消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="signMessage">签名消息</el-button>
        </el-form-item>
        <el-form-item label="签名">
          <el-input v-model="signature" type="textarea" readonly></el-input>
        </el-form-item>
        <!-- 新增用于验证尝试的签名消息输入框 -->
        <el-form-item label="用于验证的签名消息">
          <el-input v-model="signedMessageForVerification" type="textarea" placeholder="请输入或粘贴用于验证的签名消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="warning" @click="verifySignature">验证签名</el-button>
        </el-form-item>
        <el-form-item label="验证结果">
          <el-input v-model="verificationResult" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import { ec as EC } from 'elliptic';
  
  export default {
    name: 'EccEncryption',
    data() {
      return {
        ec: new EC('secp256k1'),
        keyPair: null,
        publicKey: '',
        privateKey: '',
        message: '',
        signature: '',
        signedMessageForVerification: '', // 用户可以修改的签名消息
        verificationResult: '',
      };
    },
    methods: {
      generateKeys() {
        this.keyPair = this.ec.genKeyPair();
        this.publicKey = this.keyPair.getPublic('hex');
        this.privateKey = this.keyPair.getPrivate('hex');
      },
      signMessage() {
        const msgHash = this.ec.hash().update(this.message).digest();
        const sig = this.keyPair.sign(msgHash);
        this.signature = JSON.stringify(sig.toDER('hex'));
        // 同时更新用于验证尝试的签名消息
        this.signedMessageForVerification = this.message;
      },
      verifySignature() {
        const msgHash = this.ec.hash().update(this.signedMessageForVerification).digest();
        const publicKey = this.ec.keyFromPublic(this.publicKey, 'hex');
        // 注意：这里假设signature已经是正确格式，实际应用中可能需要转换格式
        const isValid = publicKey.verify(msgHash, JSON.parse(this.signature));
        this.verificationResult = isValid ? '签名验证成功' : '签名验证失败';
      },
    },
  };
  </script>
  
  <style scoped>
  .ecc-card {
    margin-bottom: 20px;
  }
  </style>
  