<template>
  <el-container style="height: 100vh;">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu
        @select="handleSelect"
        default-active="1-1"
        class="el-menu-vertical-demo"
        collapse-transition={false}
        background-color="#eef1f6"
        text-color="#333"
        active-text-color="#409EFF">
        <!-- 菜单项定义 -->
        <el-submenu index="1">
          <template #title>电子签名</template>
          <el-menu-item-group>
            <el-menu-item index="1-1">HMAC</el-menu-item>
            <el-menu-item index="1-2">SHA-512</el-menu-item>
            
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="2">
          <template #title>对称加密</template>
          <el-menu-item-group>
            <el-menu-item index="2-1">AES</el-menu-item>
            <el-menu-item index="2-2">camellia</el-menu-item>
            <el-menu-item index="2-3">ChaChaPoly2015</el-menu-item>
            <el-menu-item index="2-4">SM4</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="3">
          <template #title>非对称加密相关</template>
          <el-menu-item-group>
            <el-menu-item index="3-1">RSA</el-menu-item>
            <el-menu-item index="3-2">Ecc</el-menu-item>
            <el-menu-item index="3-3">Ed25519公私钥对生成</el-menu-item>
            <!-- <el-menu-item index="3-4">Ed448公私钥对生成</el-menu-item> -->
          </el-menu-item-group>
          
        </el-submenu>
        <el-submenu index="4">
          <template #title>信息隐写</template>
          <el-menu-item-group>
            <el-menu-item index="4-1">嵌入文字到图片</el-menu-item>
            <el-menu-item index="4-2">从图片提取文字</el-menu-item>
            <el-menu-item index="4-3">水印嵌入</el-menu-item>
            <el-menu-item index="4-4">水印提取</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <!-- 其他菜单项 -->
      </el-menu>
    </el-aside>

    <el-container>
      <el-main>
        <!-- 根据选中的菜单项动态显示内容 -->
        <div v-if="selected === '1-1'">
          <hmac-authentication></hmac-authentication>
        </div>
        <div v-if="selected === '1-2'">
          <sha-authentication></sha-authentication>
        </div>
        <div v-if="selected === '2-3'">
          <cha-cha-20-poly-1305-encryption></cha-cha-20-poly-1305-encryption>
        </div>
        <div v-if="selected === '2-4'">
          <SM4Encryption></SM4Encryption>
        </div>
        <div v-if="selected === '2-1'">
          <aes-encryption></aes-encryption>
        </div>
        <div v-if="selected === '2-2'">
          <camellia-encryption></camellia-encryption>
        </div>
        <div v-if="selected === '3-1'">
          <Rsa-Encryption></Rsa-Encryption>
        </div>
        <div v-if="selected === '3-2'">
          <Ecc-Encryption></Ecc-Encryption>
        </div>
        <div v-if="selected === '3-3'">
          <Ed25519-KeyPair></Ed25519-KeyPair>
        </div>
        <!-- <div v-if="selected === '3-4'">
          <Ed448-KeyPair></Ed448-KeyPair>
        </div> -->
        <div v-if="selected === '4-1'">
          <ImageTextEmbedding></ImageTextEmbedding>
        </div>
        <div v-if="selected === '4-2'">
          <ImageTextExtraction></ImageTextExtraction>
        </div> 
        <div v-if="selected === '4-3'">
          <WatermarkEmbedding></WatermarkEmbedding>
        </div>
        <div v-if="selected === '4-4'">
          <WatermarkExtraction></WatermarkExtraction>
        </div>
        <!-- 其他内容的条件渲染 -->
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import AesEncryption from './AesEncryption.vue';
import CamelliaEncryption from './camellia.vue'; 
import HmacAuthentication from './hmac.vue';
import ShaAuthentication from './sha.vue';
import RsaEncryption from './rsa.vue';
import EccEncryption from './ecc.vue';
//import Ed448KeyPair from './ed448.vue';
import Ed25519KeyPair from './ed25519.vue';
import ImageTextEmbedding from './embedd.vue';
import ImageTextExtraction from './extract.vue';
import WatermarkEmbedding from './wtremb.vue';
import WatermarkExtraction from './wtrext.vue';
import ChaCha20Poly1305Encryption from './chacha.vue';
import SM4Encryption from './sm4.vue';
export default {
  components: {
    AesEncryption,
    CamelliaEncryption, 
    HmacAuthentication,
    ShaAuthentication,
    RsaEncryption,
    EccEncryption,
    Ed25519KeyPair,
    ImageTextEmbedding,
    ImageTextExtraction,
    WatermarkEmbedding,
    WatermarkExtraction,
    ChaCha20Poly1305Encryption,
    SM4Encryption,
    //Ed448KeyPair,
  },
  name: 'CryptographyTools',
  data() {
    return {
      selected: '1-1', // 默认选中项
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      this.selected = key;
    },
  },
};
</script>

<style scoped>
.el-aside {
  padding-top: 60px;
}
.el-aside {
  background-color: #eef1f6;
}
.box-card {
  margin-bottom: 20px;
}
</style>
