<template>
    <el-card class="rsa-card">
      <div slot="header" class="clearfix">
        <span>RSA 加密/解密</span>
      </div>
      <el-form label-position="top">
        <el-form-item>
          <el-button type="primary" @click="generateKeys">生成密钥对</el-button>
        </el-form-item>
        <el-form-item label="公钥">
          <el-input v-model="publicKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="私钥">
          <el-input v-model="privateKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="消息">
          <el-input v-model="message" type="textarea" placeholder="请输入消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="encryptMessage">加密消息</el-button>
        </el-form-item>
        <!-- 新增加密后的消息输入框，允许用户修改 -->
        <el-form-item label="加密后的消息（用于解密尝试）">
          <el-input v-model="encryptedMessageForDecryption" type="textarea" placeholder="请输入或粘贴加密后的消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="warning" @click="decryptMessage">解密消息</el-button>
        </el-form-item>
        <el-form-item label="解密后的消息">
          <el-input v-model="decryptedMessage" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import forge from 'node-forge';
  
  export default {
    name: 'RsaEncryption',
    data() {
      return {
        publicKey: '',
        privateKey: '',
        message: '',
        encryptedMessage: '', // 用于显示加密后的消息
        encryptedMessageForDecryption: '', // 用户可以修改的加密消息
        decryptedMessage: '',
      };
    },
    methods: {
      generateKeys() {
        const keypair = forge.pki.rsa.generateKeyPair({ bits: 2048 });
        this.publicKey = forge.pki.publicKeyToPem(keypair.publicKey);
        this.privateKey = forge.pki.privateKeyToPem(keypair.privateKey);
      },
      encryptMessage() {
        const publicKey = forge.pki.publicKeyFromPem(this.publicKey);
        const encrypted = publicKey.encrypt(this.message, 'RSA-OAEP');
        this.encryptedMessage = forge.util.encode64(encrypted);
        // 同时更新用于解密尝试的加密消息
        this.encryptedMessageForDecryption = this.encryptedMessage;
      },
      decryptMessage() {
  try {
    const privateKey = forge.pki.privateKeyFromPem(this.privateKey);
    const decrypted = privateKey.decrypt(forge.util.decode64(this.encryptedMessageForDecryption), 'RSA-OAEP');
    this.decryptedMessage = decrypted;
  } catch (error) {
    // 解密失败，显示错误消息
    this.decryptedMessage = "解密失败：无法解密消息或消息已损坏。";
  }
},

    },
  };
  </script>
  
  <style scoped>
  .rsa-card {
    margin-bottom: 20px;
  }
  </style>
  