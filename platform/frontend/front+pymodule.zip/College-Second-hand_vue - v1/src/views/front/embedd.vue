<template>
  <el-container>
    <el-card class="text-embedding-card">
      <div slot="header" class="clearfix">
        <span>嵌入文字到图片</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="选择图片">
          <el-upload
            class="upload-demo"
            :on-change="handleFileChange"
            :before-upload="beforeEmbeddingUpload"
            :auto-upload="false">
            <el-button slot="trigger" size="small" type="primary">选取图片</el-button>
            <div slot="tip" class="el-upload__tip">只支持jpg/png文件</div>
          </el-upload>
        </el-form-item>
        <el-form-item label="输入要嵌入的文字">
          <el-input v-model="textToEmbed" type="textarea" placeholder="请输入要嵌入的文字"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="embedText">嵌入文字并下载</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </el-container>
</template>

<script>
export default {
  name: 'TextEmbedding',
  data() {
    return {
      selectedFile: null,
      textToEmbed: '',
      websocket: null,
    };
  },
  created() {
    this.connectWebSocket();
  },
  methods: {
    connectWebSocket() {
      // 连接到WebSocket服务器
      this.websocket = new WebSocket("ws://192.168.80.133:8765");
      this.websocket.onopen = () => console.log("WebSocket连接成功");
      this.websocket.onerror = (error) => console.log("WebSocket连接错误", error);
      this.websocket.onmessage = (event) => {
        // 处理从服务器接收到的消息
        this.handleServerResponse(event.data);
      };
    },
    handleFileChange(file, fileList) {
      this.selectedFile = file.raw;
    },
    beforeEmbeddingUpload() {
      return false;
    },
    embedText() {
      if (!this.selectedFile || !this.textToEmbed) {
        this.$message.error("请选择图片并输入要嵌入的文字！");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target.result.split(',')[1]; // 移除"data:image/png;base64,"前缀
        const data = {
          source: "crypt",
          type: "embed_text",
          content: {
            image_path: imageData, // 只包含Base64编码的数据
            text: this.textToEmbed,
            output_path: "desired_output_path" // 服务器上的路径，用户无法选择
          }
        };
        console.log("Sending data to WebSocket server:", data); // 打印即将发送的数据
        this.websocket.send(JSON.stringify(data)); // 通过WebSocket发送数据
      };
      reader.readAsDataURL(this.selectedFile);
    },
    handleServerResponse(data) {
      // 假设服务器返回的是处理后的图片的blob
      const blob = new Blob([data], { type: 'image/png' });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = "embedded-image.png"; // 提供一个默认的下载文件名
      document.body.appendChild(link);
      link.click(); // 模拟点击以触发下载
      document.body.removeChild(link);
    },
  },
};
</script>


  
  <style scoped>
  .full-height {
  height: 100vh; /* 视口高度 */
  display: flex;
  flex-direction: column;
}

.text-embedding-card {
  flex-grow: 1; /* 使卡片填充剩余空间 */
  margin-bottom: 0; /* 移除底部的外边距 */
  border: none; /* 可选：移除边框 */
}
  .text-embedding-card {
    margin-bottom: 20px;
  }
  </style>
  