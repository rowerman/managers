<template>
    <div class="sniffer-tools" style="margin-top: 100px; padding: 20px;">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>网络嗅探器</span>
        </div>
        <el-form label-position="top">
          <el-form-item label="选择网络接口">
            <el-select v-model="selectedNetwork" placeholder="请选择">
              <el-option
                v-for="item in networks"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-table :data="sniffedData" style="width: 100%">
            <el-table-column prop="id" label="ID" width="80"></el-table-column>
            <el-table-column prop="time" label="时间" width="180"></el-table-column>
            <el-table-column prop="source" label="源地址"></el-table-column>
            <el-table-column prop="destination" label="目的地址"></el-table-column>
            <el-table-column prop="protocol" label="协议" width="120"></el-table-column>
            <el-table-column prop="length" label="长度" width="100"></el-table-column>
            <el-table-column prop="info" label="信息"></el-table-column>
          </el-table>
        </el-form>
      </el-card>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Sniffer',
    data() {
      return {
        selectedNetwork: '',
        networks: [
          { value: 'eth0', label: 'Ethernet 0' },
          { value: 'wlan0', label: 'Wi-Fi' },
          // 添加更多网络接口选项...
        ],
        sniffedData: [
          // 示例数据，实际应用中应从后端获取
          { id: 1, time: '2023-03-30 12:00:00', source: '192.168.1.1', destination: '192.168.1.2', protocol: 'TCP', length: 60, info: 'Some information' },
          // 添加更多示例数据...
        ],
      };
    },
  };
  </script>
  
  <style scoped>
  .sniffer-tools {
    max-width: 1000px;
    margin: 0 auto;
  }
  
  .box-card {
    margin-bottom: 20px;
  }
  </style>
  