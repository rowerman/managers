<template>
  <div style="margin-top: 100px">
    <el-result
      v-if="student_user.length == 0"
      icon="warning"
      title="当前未登录"
      subTitle="点击下面按钮进行登录"
    >
      <template slot="extra">
        <el-button type="primary" size="medium" @click="s_login"
          >去登录</el-button
        >
      </template>
    </el-result>
    <div v-else style="margin: 0 auto; width: 1000px">
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: center;
          padding-top: 40px;
        "
      >
        <el-input
          style="width: 600px"
          clearable
          size="medium"
          placeholder="请输入帖子名称"
          v-model="gname"
          class="input-with-select"
        >
          <el-button
            slot="append"
            icon="el-icon-search"
            @click="load"
          ></el-button>
        </el-input>
      </div>
      <el-row
        style="margin: 0 auto; padding-top: 50px; padding-bottom: 80px"
        :gutter="12"
      >
        <div style="padding-left: 30px; padding-bottom: 20px">
          <span v-if="total_sum == 0">
            <el-empty :image-size="200"></el-empty>
          </span>
          <span v-else style="color: #949494"
            >共发现 {{ total_sum }} 个帖子</span
          >
        </div>
        <el-col
          :span="4"
          v-for="goods_list in filteredGoodsList"
          :key="goods_list.gid"
          style="padding: 15px; min-width: 240px; margin-top: 20px"
        >
          <el-card
            v-if="goods_list.gstatus == 1"
            :body-style="{ padding: '0px' }"
            shadow="hover"
            style="
              cursor: pointer;
              border-radius: 15px;
              border: 1px solid #87ceeb; /* 天蓝色的实线边框 */
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* 轻微阴影效果提升立体感 */
            "
            @click.native="goods_details(goods_list.gid)"
          >
            <div
              v-if="goods_list.gdescribe !== null"
              style="
                height: 208px;
                width: 208px;
                padding: 14px;
                overflow: hidden;
                text-overflow: ellipsis;
                background-color: #f0f8ff; /* 背景使用更淡的天蓝色 */
              "
            >
              {{ goods_list.gdescribe }}
            </div>

            <div style="padding: 14px">
              <span>{{ goods_list.gname | ellipsis }}</span>
              <div class="bottom clearfix">
                <span class="time">
                  <i class="el-icon-s-shop"></i>
                  {{ goods_list.sellusername }}
                </span>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <transition v-if="isLoading" name="fade">
      <div class="loading"></div>
    </transition>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: true,
      student_user: localStorage.getItem("student_user")
        ? JSON.parse(localStorage.getItem("student_user"))
        : [],
      goods_list: [],
      total: 0,
      gname: "",
    };
  },
  created() {
    if (this.student_user.length != 0) {
      this.load();
    } else {
      this.isLoading = false;
    }
  },
  filters: {
    // 当标题字数超出时，超出部分显示’...‘。此处限制超出10位即触发隐藏效果
    ellipsis(value) {
      if (!value) return "";
      if (value.length > 10) {
        return value.slice(0, 10) + "...";
      }
      return value;
    },
  },
  computed: {
    filteredGoodsList() {
      return this.goods_list.filter((item) => item.gstatus == 1);
    },
    total_sum() {
      return this.filteredGoodsList.length; // 根据filteredGoodsList的长度计算total_sum
    },
  },
  methods: {
    s_login() {
      this.$router.push("/s_login");
    },
    load() {
      this.request
        .get(
          "/collection/getCollection?Sid=" +
            this.student_user.sid +
            "&Gname=" +
            this.gname
        )
        .then((res) => {
          this.goods_list = res.data;
          this.total = res.total;

          this.isLoading = false;
        });
    },
    goods_details(id) {
      this.$router.push({
        path: "/goods_details",
        query: {
          gid: id,
        },
      });
    },
  },
};
</script>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

.loading {
  position: fixed;
  left: 0;
  top: 0;
  background: url("../../assets/loading (2).gif") center center no-repeat #fff;
  width: 100vw;
  height: 100vh;
}
</style>
