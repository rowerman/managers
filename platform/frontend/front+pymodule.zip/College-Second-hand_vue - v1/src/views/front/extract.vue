<template>
    <el-container class="full-height">
      <el-card class="full-height text-extraction-card">
        <div slot="header" class="clearfix">
          <span>从图片提取文字</span>
        </div>
        <el-form label-position="top">
          <el-form-item label="选择图片">
            <el-upload
              class="upload-demo"
              :on-change="handleFileChange"
              :before-upload="beforeExtractionUpload"
              :auto-upload="false"
              multiple
              action="#">
              <el-button slot="trigger" size="small" type="primary">选取图片</el-button>
              <div slot="tip" class="el-upload__tip">支持多文件选择</div>
            </el-upload>
          </el-form-item>
          <el-form-item label="提取文字的长度(bit)">
            <el-input-number v-model="textLength" :min="1"></el-input-number>
          </el-form-item>
          <el-form-item>
            <el-button type="warning" @click="extractText">提取文字</el-button>
          </el-form-item>
          <el-form-item label="提取的文字">
            <el-input v-model="extractedText" type="textarea" readonly></el-input>
          </el-form-item>
        </el-form>
      </el-card>
    </el-container>
  </template>
  
  <script>
  export default {
    name: 'TextExtraction',
    data() {
      return {
        selectedFiles: [],
        textLength: 0,
        extractedText: '',
      };
    },
    methods: {
      handleFileChange(file, fileList) {
        // 保存用户选择的文件列表
        this.selectedFiles = fileList.map(fileItem => fileItem.raw);
      },
      beforeExtractionUpload() {
        // 阻止自动上传
        return false;
      },
      extractText() {
        if (this.selectedFiles.length === 0 || this.textLength === 0) {
          this.$message.error("请选择图片并设置提取文字的长度！");
          return;
        }
        // 在这里实现将图片和提取长度发送到后端的逻辑
        // 示例代码省略了实际的上传逻辑，您需要根据后端API进行相应的调整
        console.log("执行提取文字操作", this.selectedFiles, this.textLength);
        // 假设提取成功后，设置提取的文字
        this.extractedText = "这里是提取的文字示例...";
      },
    },
  };
  </script>
  
  <style scoped>
  .full-height {
    height: 100vh;
    display: flex;
    flex-direction: column;
  }
  
  .text-extraction-card {
    flex-grow: 1;
    margin-bottom: 0;
  }
  </style>
  