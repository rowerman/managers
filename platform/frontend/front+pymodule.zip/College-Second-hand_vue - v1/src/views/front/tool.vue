<template>
  <el-container style="height: 100vh;">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu
        @select="handleSelect"
        default-active="1-1"
        class="el-menu-vertical-demo"
        collapse-transition={false}
        background-color="#eef1f6"
        text-color="#333"
        active-text-color="#409EFF">
        <el-submenu index="1">
          <template #title><i class="el-icon-info"></i> SNMP管理</template>
          <el-menu-item-group>
            <el-menu-item index="1-1">获取Agent信息</el-menu-item>
            <el-menu-item index="1-2">设置Agent信息</el-menu-item>
            <el-menu-item index="1-3">监听trap包</el-menu-item>
            <el-menu-item index="1-4">发送trap包</el-menu-item>
            <el-menu-item index="1-5">Agent数据监控</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-aside>

    <el-container>
      <el-main>
        <div v-if="selected === '1-1'">
          <!-- 获取Agent信息的界面 -->
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>获取Agent信息</span>
            </div>
            <!-- 表单内容 -->
          </el-card>
        </div>
        <div v-if="selected === '1-2'">
          <!-- 设置Agent信息的界面 -->
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>设置Agent信息</span>
            </div>
            <!-- 表单内容 -->
          </el-card>
        </div>
        <!-- 其他功能的界面 -->
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  name: 'SNMPManagement',
  data() {
    return {
      selected: '1-1', // 默认选中获取Agent信息
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      this.selected = key;
    },
  },
};
</script>

<style scoped>
.el-aside {
  padding-top: 60px; /* 确保顶部有足够的空间 */
}
.el-aside {
  background-color: #eef1f6;
}

.box-card {
  margin-bottom: 20px;
}
</style>
