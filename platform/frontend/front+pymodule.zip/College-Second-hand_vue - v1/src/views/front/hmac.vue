<template>
    <el-card class="hmac-card">
      <div slot="header" class="clearfix">
        <span>HMAC 生成/验证</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="密钥（留空将自动生成）">
          <el-input v-model="hmacKey" placeholder="如果留空，将自动生成密钥"></el-input>
        </el-form-item>
        <el-form-item label="消息">
          <el-input v-model="message" type="textarea" placeholder="请输入消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="generateHmac">生成HMAC</el-button>
        </el-form-item>
        <el-form-item label="生成的HMAC">
          <el-input v-model="generatedHmac" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="验证的消息">
          <el-input v-model="verificationMessage" type="textarea" placeholder="请输入用于验证的消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="verifyHmac">验证HMAC</el-button>
        </el-form-item>
        <el-form-item label="验证结果">
          <el-input v-model="verificationResult" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import CryptoJS from 'crypto-js';
  
  export default {
    name: 'HmacAuthentication',
    data() {
      return {
        hmacKey: '',
        message: '',
        generatedHmac: '',
        verificationMessage: '',
        verificationResult: '',
      };
    },
    methods: {
      generateKey() {
        return CryptoJS.lib.WordArray.random(256 / 8).toString(CryptoJS.enc.Hex);
      },
      generateHmac() {
        if (!this.hmacKey) {
          this.hmacKey = this.generateKey();
        }
        const hmac = CryptoJS.HmacSHA256(this.message, this.hmacKey).toString();
        this.generatedHmac = hmac;
      },
      verifyHmac() {
        const hmac = CryptoJS.HmacSHA256(this.verificationMessage, this.hmacKey).toString();
        if (hmac === this.generatedHmac) {
          this.verificationResult = "验证成功：消息是完整的。";
        } else {
          this.verificationResult = "验证失败：消息可能被篡改。";
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .hmac-card {
    margin-bottom: 20px;
  }
  </style>
  