<template>
  <div class="sniffer-tools" style="margin-top: 20px; padding: 20px;">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>网络嗅探器</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="选择网络接口">
          <el-select v-model="selectedNetwork" placeholder="请选择">
            <el-option v-for="item in networks" :key="item.value" :label="item.label" :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="startSniffing">开始嗅探</el-button>
          <el-button type="danger" @click="stopSniffing">停止嗅探</el-button>
        </el-form-item>
        <el-form-item>
          <el-input v-model="srcIP" placeholder="源 IP 地址"/>
          <el-button @click="searchPackets">按源 IP 搜索</el-button>
          <el-input v-model="dstIP" placeholder="目的地 IP 地址"/>
          <el-button @click="searchPackets">按目的地 IP 搜索</el-button>
          <el-button @click="exportPackets">导出数据包</el-button>
        </el-form-item>
        <el-table :data="searchResults" class="sniffer-table" style="width: 100%" height="400px">
          <el-table-column prop="time" label="时间" width="180">
  <template v-slot="{ row }">
    <el-tooltip class="item" effect="dark" :content="row.info" placement="top">
      <!-- 在这里调用formatTime方法来格式化时间 -->
      <span>{{ formatTime(row, null, row.time) }}</span>
    </el-tooltip>
  </template>
</el-table-column>

          <el-table-column prop="src" label="源地址">
            <template v-slot="{ row }">
              <el-tooltip class="item" effect="dark" :content="row.info" placement="top">
                <span>{{ row.src }}</span>
              </el-tooltip>
            </template>
          </el-table-column>
          <el-table-column prop="dst" label="目的地址">
            <template v-slot="{ row }">
              <el-tooltip class="item" effect="dark" :content="row.info" placement="top">
                <span>{{ row.dst }}</span>
              </el-tooltip>
            </template>
          </el-table-column>
          <el-table-column prop="protocol" label="协议" width="100">
            <template v-slot="{ row }">
              <el-tooltip class="item" effect="dark" :content="row.info" placement="top">
                <span>{{ row.protocol }}</span>
              </el-tooltip>
            </template>
          </el-table-column>
          <!-- Removed the explicit "Details" column, tooltips are now part of every column -->
        </el-table>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'Sniffer',
  data() {
    return {
      selectedNetwork: '',
      networks: [
        { value: 'eth0', label: 'Ethernet 0' },
        { value: 'wlan0', label: 'Wi-Fi' },
      ],
      sniffedData: [],
      searchResults: [],
      srcIP: '',
      dstIP: '',
      socket: null,
      allSniffedData: [],
    };
  },
  mounted() {
    this.connectWebSocket();
  },
  beforeDestroy() {
    if (this.socket) {
      this.socket.close();
    }
  },
  methods: {
    formatTime(row, column, cellValue, index) {
  const date = new Date(cellValue * 1000); // 假设cellValue是一个以秒为单位的UNIX时间戳
  // 将时间格式化为hhmmss
  let hours = date.getHours().toString().padStart(2, '0');
  let minutes = date.getMinutes().toString().padStart(2, '0');
  let seconds = date.getSeconds().toString().padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`; // 返回格式化后的时间字符串
},

    rowClassName({ row }) {
      switch (row.protocol) {
        case 'TCP': return 'row-tcp';
        case 'UDP': return 'row-udp';
        case 'ICMP': return 'row-icmp';
        case 'ARP': return 'row-arp';
        default: return '';
      }
    },
    connectWebSocket() {
      this.socket = new WebSocket("ws://192.168.80.133:8766");
      this.socket.onopen = this.onWebSocketOpen;
      this.socket.onmessage = this.onWebSocketMessage;
      this.socket.onerror = this.onWebSocketError;
    },
    onWebSocketOpen() {
      console.log("[open] Connection established");
    },
    onWebSocketMessage(event) {
      const data = JSON.parse(event.data);
      if (data.message && data.source === "sniffer") {
        this.allSniffedData.push(data.message); // 改动这里，存储所有数据包
        this.searchResults.push(data.message);
        this.scrollToBottom();
      }
    },
    scrollToBottom() {
      this.$nextTick(() => {
        const table = this.$el.querySelector('.sniffer-table');
        table.scrollTop = table.scrollHeight;
      });
    },
    onWebSocketError(error) {
      console.error(`[error] ${error.message}`);
    },
    startSniffing() {
      this.allSniffedData = []; // 清空之前的数据
      this.searchResults = []; // 同时清空搜索结果
      const data = { source: "sniffer", type: "start", interface: this.selectedNetwork };
      this.socket.send(JSON.stringify(data));
    },
    stopSniffing() {
      const data = { source: "sniffer", type: "stop" };
      this.socket.send(JSON.stringify(data));
    },
    searchPackets() {
      this.searchResults = this.allSniffedData.filter(packet => {
        const srcMatch = this.srcIP ? packet.src === this.srcIP : true;
        const dstMatch = this.dstIP ? packet.dst === this.dstIP : true;
        return srcMatch && dstMatch;
      });
    },
    exportPackets() {
      const dataStr = JSON.stringify(this.allSniffedData);
      const blob = new Blob([dataStr], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = 'sniffed_packets.json';
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    },
  },
};
</script>

<style scoped>
.row-tcp { background-color: #ffcccc; }
.row-udp { background-color: #ccffcc; }
.row-icmp { background-color: #ccccff; }
.row-arp { background-color: #ffffcc; }
/* 根据需要添加更多样式 */

.sniffer-table {
  max-height: 500px;
  overflow-y: auto;
}

.sniffer-tools {
  max-width: 1000px;
  margin: 0 auto;
}

.box-card {
  margin-bottom: 20px;
}
</style>
