<template>
    <el-container class="full-height">
      <el-card class="full-height watermark-extraction-card">
        <div slot="header" class="clearfix">
          <span>提取图片中的水印</span>
        </div>
        <el-form label-position="top">
          <el-form-item label="选择需要处理的图片">
            <el-upload
              class="upload-demo"
              :on-change="handleImageChange"
              :before-upload="beforeUpload"
              :auto-upload="false"
              accept="image/*"
              action="#">
              <el-button slot="trigger" size="small" type="primary">选取图片</el-button>
              <div slot="tip" class="el-upload__tip">支持jpg/png等格式</div>
            </el-upload>
          </el-form-item>
          <el-form-item label="水印尺寸（像素）">
            <el-row>
              <el-col :span="11">
                <el-form-item label="宽度">
                  <el-input-number v-model="watermarkWidth" :min="1" label="宽度"></el-input-number>
                </el-form-item>
              </el-col>
              <el-col class="text-center" :span="2">x</el-col>
              <el-col :span="11">
                <el-form-item label="高度">
                  <el-input-number v-model="watermarkHeight" :min="1" label="高度"></el-input-number>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item label="选择保存目录">
          <input type="file" @change="handleDirectoryChange" webkitdirectory directory multiple>
        </el-form-item>

    
          <el-form-item>
            <el-button type="warning" @click="extractWatermark">提取水印</el-button>
          </el-form-item>
        </el-form>
      </el-card>
    </el-container>
  </template>
  
  <script>
  export default {
    name: 'WatermarkExtraction',
    data() {
      return {
        selectedImage: null,
        watermarkWidth: 100, // 默认水印宽度
        watermarkHeight: 50, // 默认水印高度
        savePath: '', // 用户输入的保存路径
      };
    },
    methods: {
      handleImageChange(file, fileList) {
        // 保存用户选择的图片
        this.selectedImage = file.raw;
      },
      beforeUpload() {
        // 阻止自动上传
        return false;
      },
      handleDirectoryChange(event) {
      // 这里我们只是演示如何触发目录选择
      // 实际上，由于安全限制，我们不能直接获取目录路径
      console.log(event.target.files);
      if (event.target.files.length > 0) {
        this.savePath = event.target.files[0].webkitRelativePath.split('/')[0];
        this.$message.success("目录选择成功: " + this.savePath);
      }
    },
      extractWatermark() {
        if (!this.selectedImage || !this.watermarkWidth || !this.watermarkHeight || !this.savePath) {
          this.$message.error("请选择图片、输入水印尺寸并指定保存路径！");
          return;
        }
        // 在这里实现将图片和水印尺寸发送到后端的逻辑
        console.log("执行提取水印操作", this.selectedImage, this.watermarkWidth, this.watermarkHeight, this.savePath);
        // 假设提取成功后，触发浏览器下载处理后的图片和水印
      },
    },
  };
  </script>
  
  <style scoped>
  .full-height {
    height: 100vh;
    display: flex;
    flex-direction: column;
  }
  
  .watermark-extraction-card {
    flex-grow: 1;
    margin-bottom: 0;
  }
  
  .text-center {
    text-align: center;
    line-height: 32px;
  }
  </style>
  