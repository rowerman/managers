<template>
  <div style="margin-top: 100px">
    <el-result
      v-if="student_user.length == 0"
      icon="warning"
      title="当前未登录"
      subTitle="点击下面按钮进行登录"
    >
      <template slot="extra">
        <el-button type="primary" size="medium" @click="s_login"
          >去登录</el-button
        >
      </template>
    </el-result>
    <div v-else style="margin: 0 auto; width: 900px">
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: center;
          padding-top: 40px;
        "
      >
        <el-input
          style="width: 600px"
          clearable
          size="medium"
          placeholder="请输入帖子名称"
          v-model="gname"
          class="input-with-select"
        >
          <el-select v-model="status" slot="prepend" placeholder="请选择">
            <el-option label="全部" value=""></el-option>
            <el-option label="已撤销" value="3"></el-option>
          </el-select>
          <el-button
            slot="append"
            icon="el-icon-search"
            @click="load"
          ></el-button>
        </el-input>
      </div>

      <el-row style="margin: 0 auto; padding-top: 50px; padding-bottom: 80px">
        <div style="padding-left: 30px; padding-bottom: 20px">
          <span v-if="total_sum == 0">
            <el-empty :image-size="200"></el-empty>
          </span>
          <span v-else style="color: #949494"
            >共发现 {{ total_sum }} 个帖子</span
          >
        </div>
        <el-card
          :body-style="{ padding: '11px' }"
          v-for="goods_list in filteredGoodsList"
          :key="goods_list.gid"
          shadow="hover"
          style="
            cursor: pointer;
            margin-bottom: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s;
            border: 1px solid #87ceeb;
          "
          @click.native="goods_details(goods_list.gid)"
        >
          <div style="display: flex">
            <div
              style="
                padding: 14px;
                flex-grow: 1;
                display: flex;
                flex-direction: column;
                justify-content: center;
              "
            >
              <span style="font-weight: 600; font-size: 1.1em">{{
                goods_list.gname
              }}</span>
              <div
                v-if="goods_list.gdescribe !== null"
                style="
                  height: 208px;
                  width: 208px;
                  padding: 14px;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  background-color: #f0f8ff; /* 背景使用更淡的天蓝色 */
                "
              >
                <span style="margin-top: 10px; color: #606266">{{
                  goods_list.gdescribe | ellipsis
                }}</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-row>
    </div>
    <transition v-if="isLoading" name="fade">
      <div class="loading"></div>
    </transition>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: true,
      student_user: localStorage.getItem("student_user")
        ? JSON.parse(localStorage.getItem("student_user"))
        : [],
      goods_list: [],
      gname: "",
      total: 0,
      status: "",
    };
  },
  filters: {
    // 当标题字数超出时，超出部分显示’...‘。此处限制超出90位即触发隐藏效果
    ellipsis(value) {
      if (!value) return "";
      if (value.length > 90) {
        return value.slice(0, 90) + "...";
      }
      return value;
    },
  },
  created() {
    if (this.student_user.length != 0) {
      this.load();
    } else {
      this.isLoading = false;
    }
  },
  computed: {
    filteredGoodsList() {
      return this.goods_list.filter((item) => item.gstatus == 1);
    },
    total_sum() {
      return this.filteredGoodsList.length; // 根据filteredGoodsList的长度计算total_sum
    },
  },
  methods: {
    s_login() {
      this.$router.push("/s_login");
    },
    load() {
      this.request
        .get(
          "/goods/getSidGoods?Sid=" +
            this.student_user.sid +
            "&Gstatus=" +
            this.status +
            "&Gname=" +
            this.gname
        )
        .then((res) => {
          this.goods_list = res.data;
          this.total = res.total;

          this.isLoading = false;
        });
    },
    goods_details(id) {
      this.$router.push({
        path: "/my_goods_details",
        query: {
          gid: id,
        },
      });
    },
  },
};
</script>

<style>
.el-card__body,
.el-main {
  padding: 11px;
}
.el-select .el-input {
  width: 103px;
}
.input-with-select .el-input-group__prepend {
  background-color: #fff;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

.loading {
  position: fixed;
  left: 0;
  top: 0;
  background: url("../../assets/loading (2).gif") center center no-repeat #fff;
  width: 100vw;
  height: 100vh;
}
</style>
