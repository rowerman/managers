<template>
    <el-card class="sha-card">
      <div slot="header" class="clearfix">
        <span>SHA 加密</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="选择SHA类型">
          <el-select v-model="selectedShaType" placeholder="请选择SHA类型">
            <el-option label="SHA-1" value="SHA-1"></el-option>
            <el-option label="SHA-256" value="SHA-256"></el-option>
            <el-option label="SHA-512" value="SHA-512"></el-option>
            <!-- 可以根据需要添加更多的SHA类型 -->
          </el-select>
        </el-form-item>
        <el-form-item label="消息">
          <el-input v-model="message" type="textarea" placeholder="请输入消息..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="encrypt">加密</el-button>
        </el-form-item>
        <el-form-item label="生成的哈希值">
          <el-input v-model="generatedHash" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import CryptoJS from 'crypto-js';
  
  export default {
    name: 'ShaEncryption',
    data() {
      return {
        selectedShaType: '',
        message: '',
        generatedHash: '',
      };
    },
    methods: {
      encrypt() {
        switch (this.selectedShaType) {
          case 'SHA-1':
            this.generatedHash = CryptoJS.SHA1(this.message).toString();
            break;
          case 'SHA-256':
            this.generatedHash = CryptoJS.SHA256(this.message).toString();
            break;
          case 'SHA-512':
            this.generatedHash = CryptoJS.SHA512(this.message).toString();
            break;
          // 可以根据需要添加更多的SHA类型
          default:
            this.generatedHash = '请选择一个SHA类型';
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .sha-card {
    margin-bottom: 20px;
  }
  </style>
  