<template>
    <el-card class="ed448-card">
      <div slot="header" class="clearfix">
        <span>Ed448 密钥对生成</span>
      </div>
      <el-form label-position="top">
        <el-form-item>
          <el-button type="primary" @click="generateKeys">生成密钥对</el-button>
        </el-form-item>
        <el-form-item label="公钥">
          <el-input v-model="publicKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="私钥">
          <el-input v-model="privateKey" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  export default {
    name: 'Ed448KeyPair',
    data() {
      return {
        publicKey: '',
        privateKey: '',
      };
    },
    methods: {
      async generateKeys() {
        // 假设有一个异步函数generateEd448KeyPair()可以生成Ed448密钥对
        // 这里的实现需要根据你实际使用的库进行调整
        const { publicKey, privateKey } = await generateEd448KeyPair();
        this.publicKey = publicKey; // 假设这是以某种形式编码的公钥
        this.privateKey = privateKey; // 假设这是以某种形式编码的私钥
      },
    },
  };
  </script>
  
  <style scoped>
  .ed448-card {
    margin-bottom: 20px;
  }
  </style>
  