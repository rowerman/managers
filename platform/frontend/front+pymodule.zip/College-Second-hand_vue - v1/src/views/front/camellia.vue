<template>
  <el-card class="camellia-card">
    <div slot="header" class="clearfix">
      <span>Camellia 加密/解密</span>
    </div>
    <el-form label-position="top">
      <el-form-item label="密钥（留空将自动生成）">
        <el-input v-model="camelliaKey" placeholder="如果留空，将自动生成密钥"></el-input>
      </el-form-item>
      <el-form-item label="密钥长度（位）">
  <el-select v-model="keyLength" placeholder="请选择密钥长度">
    <el-option label="128" value="128"></el-option>
    <el-option label="192" value="192"></el-option>
    <el-option label="256" value="256"></el-option>
  </el-select>
</el-form-item>

      <el-form-item label="明文（加密用）">
        <el-input v-model="plaintext" type="textarea" placeholder="请输入明文..."></el-input>
      </el-form-item>
      <el-form-item label="密文（解密用）">
        <el-input v-model="ciphertext" type="textarea" placeholder="请输入密文..."></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="sendEncryptRequest">加密</el-button>
        <el-button type="success" @click="sendDecryptRequest">解密</el-button>
      </el-form-item>
      <el-form-item label="生成的密文">
        <el-input v-model="generatedCiphertext" type="textarea" readonly></el-input>
      </el-form-item>
      <el-form-item label="解密后的明文">
        <el-input v-model="decryptedPlaintext" type="textarea" readonly></el-input>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
export default {
  name: 'CamelliaEncryption',
  data() {
    return {
      socket: null,
      camelliaKey: '',
      plaintext: '',
      ciphertext: '',
      generatedCiphertext: '',
      decryptedPlaintext: '',
      keyLength: 128,
    };
  },
  created() {
    this.connect();
  },
  methods: {
    connect() {
      this.socket = new WebSocket('ws://192.168.80.133:8765');
      this.socket.onopen = () => {
        console.log('WebSocket connected');
      };
      
      this.socket.onerror = (error) => {
        console.error('WebSocket Error:', error); 
      };
    },
    generateRandomKey() {
      let key = '';
      for (let i = 0; i < 32; i++) {
        key += Math.floor(Math.random() * 16).toString(16);
      }
      return key;
    },
    sendEncryptRequest() {
  let key = this.camelliaKey;
  let type = key ? 1 : 3; // 使用自定义密钥还是后端生成

  const message = {
    source: "crypt",
    type: 'Camellia_encrypt_keys',
    content: {
      message: this.plaintext,
      len_key: this.keyLength, // 使用选择的密钥长度
      type: type,
      key: key || '', // 没有密钥时发送空字符串
      filepath: ''
    }
  };
  
  this.socket.send(JSON.stringify(message));
  console.log('Sent encrypt request:', message);

  // 如果没有提供密钥，等待后端响应并更新camelliaKey
  if (!key) {
    this.socket.onmessage = (event) => {
      const response = JSON.parse(event.data);
      if (response.message_type === 'server_reply' && response.message === 'Camellia_encrypt_keys_result') {
        this.camelliaKey = response.package.key; // 假设后端返回的密钥在package.key中
        this.generatedCiphertext = response.package.ciphertext;
      }
    };
  }
},



sendDecryptRequest() {
  const message = {
    source: "crypt",
    type: 'Camellia_decrypt_keys',
    content: {
      ciphertext: this.ciphertext,
      len_key: this.keyLength, // 确保使用正确的密钥长度
      key: this.camelliaKey // 使用存储的密钥
    }
  };

  this.socket.send(JSON.stringify(message));
  console.log('Sent decrypt request:', message);

  // 设置一个处理程序来处理解密响应
  this.socket.onmessage = (event) => {
    const response = JSON.parse(event.data);
    if (response.message_type === 'server_reply' && response.message === 'Camellia_decrypt_keys_result') {
      // 假设解密后的明文在response.package.message中
      this.decryptedPlaintext = response.package.message;
      console.log('Received decrypted plaintext:', response.package.message);
    }
  };
},

  },
};
</script>

<style scoped>
.camellia-card {
  margin-bottom: 20px;
}
</style>
