<template>
    <el-card class="ed25519-card">
      <div slot="header" class="clearfix">
        <span>Ed25519 密钥对生成</span>
      </div>
      <el-form label-position="top">
        <el-form-item>
          <el-button type="primary" @click="generateKeys">生成密钥对</el-button>
        </el-form-item>
        <el-form-item label="公钥">
          <el-input v-model="publicKey" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="私钥">
          <el-input v-model="privateKey" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import nacl from 'tweetnacl';
  import naclUtil from 'tweetnacl-util';
  
  export default {
    name: 'Ed25519KeyPair',
    data() {
      return {
        publicKey: '',
        privateKey: '',
      };
    },
    methods: {
      generateKeys() {
        const keyPair = nacl.sign.keyPair();
        this.publicKey = naclUtil.encodeBase64(keyPair.publicKey);
        this.privateKey = naclUtil.encodeBase64(keyPair.secretKey);
      },
    },
  };
  </script>
  
  <style scoped>
  .ed25519-card {
    margin-bottom: 20px;
  }
  </style>
  