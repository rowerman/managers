<template>
    <el-card class="aes-card">
      <div slot="header" class="clearfix">
        <span>AES 加密/解密</span>
      </div>
      <el-form label-position="top">
        <el-form-item label="密钥（留空将自动生成）">
          <el-input v-model="aesKey" placeholder="如果留空，将自动生成密钥"></el-input>
        </el-form-item>
        <el-form-item label="明文（加密用）">
          <el-input v-model="plaintext" type="textarea" placeholder="请输入明文..."></el-input>
        </el-form-item>
        <el-form-item label="密文（解密用）">
          <el-input v-model="ciphertext" type="textarea" placeholder="请输入密文..."></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="encrypt">加密</el-button>
          <el-button type="success" @click="decrypt">解密</el-button>
        </el-form-item>
        <el-form-item label="生成的密文">
          <el-input v-model="generatedCiphertext" type="textarea" readonly></el-input>
        </el-form-item>
        <el-form-item label="解密后的明文">
          <el-input v-model="decryptedPlaintext" type="textarea" readonly></el-input>
        </el-form-item>
      </el-form>
    </el-card>
  </template>
  
  <script>
  import CryptoJS from 'crypto-js';
  
  export default {
    name: 'AesEncryption',
    data() {
      return {
        aesKey: '',
        plaintext: '',
        ciphertext: '',
        generatedCiphertext: '',
        decryptedPlaintext: '',
      };
    },
    methods: {
      generateKey() {
        // 生成一个随机的256位密钥
        return CryptoJS.lib.WordArray.random(256 / 8).toString(CryptoJS.enc.Hex);
      },
      encrypt() {
        if (!this.aesKey) {
          this.aesKey = this.generateKey();
        }
        const encrypted = CryptoJS.AES.encrypt(this.plaintext, this.aesKey).toString();
        this.generatedCiphertext = encrypted;
      },
      decrypt() {
        try {
          const decrypted = CryptoJS.AES.decrypt(this.ciphertext, this.aesKey).toString(CryptoJS.enc.Utf8);
          this.decryptedPlaintext = decrypted;
        } catch (e) {
          this.decryptedPlaintext = "解密失败，请检查密钥和密文是否匹配。";
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .aes-card {
    margin-bottom: 20px;
  }
  </style>
  